﻿using Azurite.Infrastructure.Mapping.Contracts;
using Azurite.Storehouse.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Azurite.Storehouse.Wrappers
{
    public class CustomerW : IMap, IMapFrom<Customer>
    {
        public Guid Id { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        public string ZipCode { get; set; }
        public string Company { get; set; }
        public string VatID { get; set; }

        public virtual ICollection<OrderW> Orders { get; set; }

        public CustomerW()
        {
            this.Orders = new HashSet<OrderW>();
        }
    }
}