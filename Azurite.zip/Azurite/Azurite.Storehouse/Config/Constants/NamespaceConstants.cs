﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Azurite.Storehouse.Config.Constants
{
    public static class NamespaceConstants
    {
        public static string Config = "Azurite.Storehouse.Config";
        public static string Workers = "Azurite.Storehouse.Workers";
    }
}