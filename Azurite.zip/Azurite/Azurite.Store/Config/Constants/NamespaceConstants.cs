﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Azurite.Store.Config.Constants
{
    public static class NamespaceConstants
    {
        public static string Config = "Azurite.Store.Config";
        public static string Workers = "Azurite.Store.Workers";
    }
}