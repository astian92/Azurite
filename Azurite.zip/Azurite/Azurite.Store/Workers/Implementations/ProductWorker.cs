﻿using Azurite.Infrastructure.Data.Contracts;
using Azurite.Store.Data;
using Azurite.Store.Workers.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Azurite.Store.Wrappers;
using AutoMapper;

namespace Azurite.Store.Workers.Implementations
{
    public class ProductWorker : IProductWorker
    {
        private readonly IRepository<Product> rep;

        public ProductWorker(IRepository<Product> rep)
        {
            this.rep = rep;
        }

        public IQueryable<ProductW> GetProducts(Guid categoryId)
        {
            var products = rep.GetAll();
            var wrapped = new List<ProductW>();

            foreach (var product in products.Where(x => x.CategoryId == categoryId))
            {
                var mapped = Mapper.Map<ProductW>(product);
                wrapped.Add(mapped);
            }

            return wrapped.AsQueryable();
        }
    }
}